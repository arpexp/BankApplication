package com.zeta.BankApplication.controller;

import com.zeta.BankApplication.entity.BankAccount;
import com.zeta.BankApplication.entity.Customer;
import com.zeta.BankApplication.entity.Transaction;
import com.zeta.BankApplication.model.BankAccountTransactionVO;
import com.zeta.BankApplication.model.TransactionVO;
import com.zeta.BankApplication.service.BankAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by arpit on 09-05-2020.
 */
@Controller
@RequestMapping("/bankaccount")
public class BankAccountController {

    @Autowired
    private BankAccountService bankAccountService;


    @PostMapping ("/withdraw")
    public ResponseEntity<String> withdraw(@RequestBody BankAccountTransactionVO bankAccountTransactionVO)
            throws IOException
    {
        bankAccountService.withdraw(bankAccountTransactionVO.getAmount() , bankAccountTransactionVO.getAccountNumber());
        return new ResponseEntity<>("Withdraw success", HttpStatus.OK);
    }

    @GetMapping ("/getTransaction/{accountNumber}")
    @ResponseBody
    public ResponseEntity<List<TransactionVO>> getTransactionList(@PathVariable(value="accountNumber") Long accountNumber) throws IOException
    {
       List<TransactionVO> transactionVOList= bankAccountService.getTransactionList(accountNumber);
        return new ResponseEntity<>(transactionVOList,HttpStatus.OK);
    }


    @GetMapping ("/getminiTransaction/{accountNumber}")
    @ResponseBody
    public ResponseEntity<List<TransactionVO>> getminitransactionVOList(@PathVariable(value="accountNumber") Long accountNumber) throws IOException
    {
        List<TransactionVO> mtransactionVOList= bankAccountService.getminiTransactionList(accountNumber);


        return new ResponseEntity<>(mtransactionVOList,HttpStatus.OK);
    }



    }

