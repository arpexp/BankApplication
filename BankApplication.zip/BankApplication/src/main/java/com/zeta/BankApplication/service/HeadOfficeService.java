package com.zeta.BankApplication.service;

import com.zeta.BankApplication.entity.Branch;
import com.zeta.BankApplication.model.BranchVO;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by arpit on 09-05-2020.
 */
@Service
public interface HeadOfficeService {

    public void createBranch(Integer headofficeId,String branchName);

    public void createHeadBranch(String branchName);

    public List<Branch> getBranchbyId(Long BranchId);

    public List<Branch> getAllBranches();

}
