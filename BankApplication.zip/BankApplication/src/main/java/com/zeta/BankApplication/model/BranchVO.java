package com.zeta.BankApplication.model;

/**
 * Created by arpit on 11-05-2020.
 */
public class BranchVO {
    private Long HeadOfficeId;
    private String HeadOfficeName;
    private Long BranchId;
    private  String BranchName;

    public Long getHeadOfficeId() {
        return HeadOfficeId;
    }

    public void setHeadOfficeId(Long headOfficeId) {
        HeadOfficeId = headOfficeId;
    }

    public String getHeadOfficeName() {
        return HeadOfficeName;
    }

    public void setHeadOfficeName(String headOfficeName) {
        HeadOfficeName = headOfficeName;
    }

    public Long getBranchId() {
        return BranchId;
    }

    public void setBranchId(Long branchId) {
        BranchId = branchId;
    }

    public String getBranchName() {
        return BranchName;
    }

    public void setBranchName(String branchName) {
        BranchName = branchName;
    }
}
