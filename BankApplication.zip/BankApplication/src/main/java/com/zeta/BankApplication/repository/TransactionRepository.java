package com.zeta.BankApplication.repository;

import com.zeta.BankApplication.entity.BankAccount;
import com.zeta.BankApplication.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by arpit on 09-05-2020.
 */
@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    @Query(value = "Select txn from TRANSACTION txn limit 10" +
            "inner join bank_account bk" +
            "on bk.accountNumber=txn.account_number " +
            "WHERE accountNumber = :accountNumber order by id desc", nativeQuery = true)
    List<Transaction> findAllBy( @Param("accountNumber") Long accountNumber);

   List<Transaction> findTransactionsByTransactionIdOrderByTransactionIdDesc(Long accountNumber);




}
