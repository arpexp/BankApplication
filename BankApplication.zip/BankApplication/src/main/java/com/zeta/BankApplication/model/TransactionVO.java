package com.zeta.BankApplication.model;

import com.zeta.BankApplication.entity.Transaction;

import javax.persistence.Column;
import java.util.List;

/**
 * Created by arpit on 10-05-2020.
 */
public class TransactionVO {

    private Long accountNumber;

    private Double currentBalance;

    private Double interestRate;

    private String accountType;

    public Long getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(Long accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Double getCurrentBalance() {
        return currentBalance;
    }

    public void setCurrentBalance(Double currentBalance) {
        this.currentBalance = currentBalance;
    }

    public Double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(Double interestRate) {
        this.interestRate = interestRate;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
}
