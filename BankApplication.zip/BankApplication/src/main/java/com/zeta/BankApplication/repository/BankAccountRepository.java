package com.zeta.BankApplication.repository;

import com.zeta.BankApplication.entity.BankAccount;
import com.zeta.BankApplication.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by arpit on 09-05-2020.
 */
@Repository
public interface BankAccountRepository extends JpaRepository<BankAccount,Long> {

    BankAccount findBankAccountsByAccountNumber(Long accountNumber);



}
