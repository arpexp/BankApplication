package com.zeta.BankApplication.controller;

import com.zeta.BankApplication.entity.Branch;
import com.zeta.BankApplication.repository.BranchRepository;
import com.zeta.BankApplication.repository.HeadOfficeRepository;
import com.zeta.BankApplication.service.HeadOfficeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by arpit on 09-05-2020.
 */
@Controller
@RequestMapping("/bank")
public class HeadOfficeController {

    @Autowired
    private HeadOfficeService headOfficeService;

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private HeadOfficeRepository headOfficeRepository;

    @PostMapping("/office")
    public ResponseEntity<String> createBranch(@RequestParam("headofficeId") Integer headofficeId, @RequestParam("branchname") String branchName) {
        headOfficeService.createBranch(headofficeId, branchName);
        return new ResponseEntity<String>(HttpStatus.CREATED);
    }

    @PostMapping("/headoffice")
    public ResponseEntity<String> createHeadBranch(@RequestParam("branchName") String branchName) {
        headOfficeService.createHeadBranch(branchName);
        return new ResponseEntity<String>(HttpStatus.CREATED);


    }

    @GetMapping("/getbranch/{id}")
    public List<Branch> getBranchById(@PathVariable(value="id")Long id)
    {
        List<Branch> branchList= new ArrayList<>();
        headOfficeRepository.findAllByBranchList(id);
        return  branchList;
    }

    @GetMapping("/getallbranch")
    public List<Branch> getAllBranch()
    {
        return  headOfficeRepository.findAllBy();
    }
}

