package com.zeta.BankApplication.serviceImpl;

import com.zeta.BankApplication.entity.Branch;
import com.zeta.BankApplication.entity.HeadOffice;
import com.zeta.BankApplication.model.BranchVO;
import com.zeta.BankApplication.repository.BranchRepository;
import com.zeta.BankApplication.repository.HeadOfficeRepository;
import com.zeta.BankApplication.service.HeadOfficeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Created by arpit on 09-05-2020.
 */

@Service
public class HeadOfficeServiceImpl implements HeadOfficeService {

    @Autowired
    HeadOfficeRepository headOfficeRepository;

    @Autowired
    BranchRepository branchRepository;
    @Override
    public void createBranch(Integer headofficeId,String branchName) {
        Optional<HeadOffice> optional = headOfficeRepository.findById(new Long(headofficeId));
        if(optional.isPresent()){
            HeadOffice headOffice = optional.get();
            Branch branch = new Branch();
            branch.setName(branchName);
            branch.setHeadOffice(headOffice);
            branchRepository.save(branch);

        }


    }

    @Override
    public void createHeadBranch(String branchName) {
        HeadOffice headOffice= new HeadOffice();
        headOffice.setName(branchName);
        headOfficeRepository.save(headOffice);
    }

    @Override
    public List<Branch> getBranchbyId(Long branchId) {

        List<Branch> branchList=headOfficeRepository.findAllByBranchList(branchId);
        return branchList;
    }

    @Override
    public List<Branch> getAllBranches() {

        List<Branch> branchList=headOfficeRepository.findAllBy();
        return branchList;
    }

}

