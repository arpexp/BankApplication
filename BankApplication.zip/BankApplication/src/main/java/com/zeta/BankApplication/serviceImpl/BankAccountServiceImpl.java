package com.zeta.BankApplication.serviceImpl;

import com.zeta.BankApplication.entity.BankAccount;
import com.zeta.BankApplication.entity.Customer;
import com.zeta.BankApplication.entity.Transaction;
import com.zeta.BankApplication.model.TransactionVO;
import com.zeta.BankApplication.repository.BankAccountRepository;
import com.zeta.BankApplication.repository.TransactionRepository;
import com.zeta.BankApplication.service.BankAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by arpit on 09-05-2020.
 */
@Service
public class BankAccountServiceImpl implements BankAccountService {

    @Autowired
    private BankAccountRepository bankAccountRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Override
    public void withdraw(Double amount, Long accountNumber) throws IOException {
        try {
            BankAccount bankAccount = bankAccountRepository.findBankAccountsByAccountNumber(accountNumber);
            Double currentBalance = bankAccount.getCurrentBalance();
            if ( currentBalance < amount) {
                throw new IOException("Account Balance Insufficent");
            } else {
                bankAccount.setCurrentBalance(currentBalance - amount);
                bankAccountRepository.save(bankAccount);
                Transaction transaction=new Transaction();
                transaction.setAmount(amount);
                transaction.setType("debit");
                transaction.setBankAccount(bankAccount);
                transactionRepository.save(transaction);

            }
        } catch (Exception e) {
            throw new IOException(e);
        }

    }

    @Override
    public void deposit(Double amount, Long accountNumber) throws IOException {

        try{
            BankAccount bankAccount=bankAccountRepository.findBankAccountsByAccountNumber(accountNumber);
            Double currentBalance=bankAccount.getCurrentBalance();
            bankAccount.setCurrentBalance(currentBalance + amount);
            bankAccountRepository.save(bankAccount);
            Transaction transaction=new Transaction();
            transaction.setAmount(amount);
            transaction.setType("credit");
            transaction.setBankAccount(bankAccount);
            transactionRepository.save(transaction);


        }
        catch (Exception e)  {
            throw new IOException(e);
        }

    }

    @Override
    public List<TransactionVO> getTransactionList(Long accountNumber) throws IOException
    {
        List<TransactionVO> transactionVOList= new ArrayList<>();
        BankAccount bankAccount= bankAccountRepository.findBankAccountsByAccountNumber(accountNumber);
        transactionVOList=  funcUtility(bankAccount.getTransactionList());
        return transactionVOList;
    }


    @Override
    public List<TransactionVO> getminiTransactionList(Long accountNumber) throws  IOException
    {
        List<Transaction> transaction= transactionRepository.findTransactionsByTransactionIdOrderByTransactionIdDesc(accountNumber);
       List<TransactionVO> transactionVOList= new ArrayList<>();
       transactionVOList=funcUtility(transaction);
       return transactionVOList;
    }

    public List<TransactionVO> funcUtility(List<Transaction> transactionList)
    {
        List<TransactionVO> transactionVOList= new ArrayList<>();
        for( Transaction transaction : transactionList)
        {
            BankAccount bankAccount = transaction.getBankAccount();
            TransactionVO transactionVO= new TransactionVO();
            transactionVO.setAccountNumber(bankAccount.getAccountNumber());
            transactionVO.setAccountType(bankAccount.getAccountType());
            transactionVO.setCurrentBalance(bankAccount.getCurrentBalance());
            transactionVO.setInterestRate(bankAccount.getInterestRate());
            transactionVOList.add(transactionVO);

        }
        return  transactionVOList;
    }


}
